A Pen created at CodePen.io. You can find this one at https://codepen.io/MarcoGuglielmelli/pen/lLCxy.

 Full-page background made with JavaScript and Canvas: the animation follows movement on non-touch devices

Based on: http://tympanus.net/Development/AnimatedHeaderBackgrounds/